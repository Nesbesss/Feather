/* eslint-disable no-underscore-dangle, no-console */
import { runScriptlet, clearGlobalProps } from '../helpers';
import { isEmptyObject } from '../../src/helpers/object-utils';

const { test, module } = QUnit;
const name = 'prevent-fetch';

const FETCH_OBJECTS_PATH = './test-files';
const nativeFetch = fetch;
const nativeConsole = console.log;
const nativeResponseJson = Response.prototype.json;

const beforeEach = () => {
    window.__debug = () => {
        window.hit = 'FIRED';
    };
};

const afterEach = () => {
    clearGlobalProps('hit', '__debug');
    fetch = nativeFetch; // eslint-disable-line no-global-assign
    console.log = nativeConsole;
    Response.prototype.json = nativeResponseJson;
};

module(name, { beforeEach, afterEach });

const isSupported = typeof fetch !== 'undefined' && typeof Proxy !== 'undefined' && typeof Response !== 'undefined';

// TODO: add testcases with POST requests
if (!isSupported) {
    test('unsupported', (assert) => {
        assert.ok(true, 'Browser does not support it');
    });
} else {
    test('Checking if alias name works', (assert) => {
        const adgParams = {
            name,
            engine: 'test',
            verbose: true,
        };
        const uboParams = {
            name: 'ubo-no-fetch-if.js',
            engine: 'test',
            verbose: true,
        };

        const codeByAdgParams = window.scriptlets.invoke(adgParams);
        const codeByUboParams = window.scriptlets.invoke(uboParams);

        assert.strictEqual(codeByAdgParams, codeByUboParams, 'ubo name - ok');
    });

    test('simple fetch - no args - logging', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const TEST_METHOD = 'GET';
        const init = {
            method: TEST_METHOD,
        };
        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };
        const done = assert.async();

        // mock console.log function for log checking
        console.log = function log(input) {
            if (input.includes('trace')) {
                return;
            }
            const EXPECTED_LOG_STR_START = `${name}: fetch( url:"${INPUT_JSON_PATH}" method:"${TEST_METHOD}"`;
            assert.ok(input.startsWith(EXPECTED_LOG_STR_START), 'console.hit input');
        };

        // no args -> just logging, no preventing
        runScriptlet(name);

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        assert.deepEqual(actualJson, expectedJson);
        done();
    });

    test('simple fetch - no match props - no prevent', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };
        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        // no url match
        runScriptlet(name, ['/test06/ method:POST']);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson);
        assert.strictEqual(window.hit, undefined, 'hit should not fire');
        done();
    });

    test('prevent any fetch call', async (assert) => {
        const INPUT_JSON_PATH_1 = `${FETCH_OBJECTS_PATH}/test01.json`;
        const inputRequest1 = new Request(INPUT_JSON_PATH_1);

        const INPUT_JSON_PATH_2 = `${FETCH_OBJECTS_PATH}/test02.json`;
        const init2 = {
            method: 'GET',
        };

        const inputRequest2 = new Request(INPUT_JSON_PATH_2, init2);

        // match any fetch
        runScriptlet(name, ['*']);
        const done = assert.async(2);

        const response1 = await fetch(inputRequest1);
        const parsedData1 = await response1.json();

        assert.ok(isEmptyObject(parsedData1), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
        // remove 'hit' property for following checking
        clearGlobalProps('hit');

        const response2 = await fetch(inputRequest2);
        const parsedData2 = await response2.json();

        assert.ok(isEmptyObject(parsedData2), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('prevent not existing fetch call', async (assert) => {
        // blocked_request.json doesn't exist,
        // it's required for test for blocked requests
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;
        const inputRequest = new Request(BLOCKED_REQUEST);

        runScriptlet(name, ['blocked_request']);
        const done = assert.async(1);

        const response = await fetch(inputRequest);
        const parsedData = await response.json();

        if (!response.ok) {
            assert.strictEqual(response.ok, true, 'Request blocked');
            done();
        }
        assert.ok(response.url.includes('/blocked_request.json'), 'Response URL is mocked');
        assert.ok(isEmptyObject(parsedData), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - match single pair prop', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test03.json`;
        const options = {
            method: 'HEAD',
        };

        runScriptlet(name, ['method:HEAD']);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, options);
        const parsedData = await response.json();

        assert.ok(isEmptyObject(parsedData), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - match few props', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test04.json`;
        const init = {
            method: 'POST',
        };

        runScriptlet(name, ['/test04/ method:POST']);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const parsedData = await response.json();

        assert.ok(isEmptyObject(parsedData), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('fetch request - match few props', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test02.json`;
        const init = {
            method: 'HEAD',
        };

        const inputRequest = new Request(INPUT_JSON_PATH, init);

        runScriptlet(name, ['/02\\.json/ method:/GET|HEAD/']);
        const done = assert.async();

        const response = await fetch(inputRequest);
        const parsedData = await response.json();

        assert.ok(isEmptyObject(parsedData), 'Response is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('fetch request - no match at all', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const inputRequest = new Request(INPUT_JSON_PATH, init);
        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        // no match at all
        runScriptlet(name, ['/06\\.json/ method:/HEAD|POST/']);
        const done = assert.async();

        const response = await fetch(inputRequest);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson);
        assert.strictEqual(window.hit, undefined, 'hit should not fire');
        done();
    });

    test('fetch request - no match - invalid regexp pattern', async (assert) => {
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const inputRequest = new Request(INPUT_JSON_PATH, init);
        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        // no match at all
        runScriptlet(name, ['/\\/ method:/*/']);
        const done = assert.async();

        const response = await fetch(inputRequest);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson);
        assert.strictEqual(window.hit, undefined, 'hit should not fire');
        done();
    });

    test('prevent all, fetch returns empty array', async (assert) => {
        const INPUT_JSON_PATH_1 = `${FETCH_OBJECTS_PATH}/test01.json`;
        const inputRequest1 = new Request(INPUT_JSON_PATH_1);

        // match any fetch
        runScriptlet(name, ['*', 'emptyArr']);
        const done = assert.async();

        const response = await fetch(inputRequest1);
        const parsedData = await response.json();

        assert.ok(Array.isArray(parsedData) && parsedData.length === 0, 'Response is empty array');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - returns empty string', async (assert) => {
        const INPUT_JSON_PATH_1 = `${FETCH_OBJECTS_PATH}/test01.json`;
        const inputRequest1 = new Request(INPUT_JSON_PATH_1);

        runScriptlet(name, ['test01', 'emptyStr']);
        const done = assert.async();

        const response = await fetch(inputRequest1);
        const parsedData = await response.text();
        assert.strictEqual(parsedData, '', 'Response is empty string');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - returns random string of 10 symbols', async (assert) => {
        const INPUT_JSON_PATH_1 = `${FETCH_OBJECTS_PATH}/test01.json`;
        const inputRequest1 = new Request(INPUT_JSON_PATH_1);

        runScriptlet(name, ['test01', 'true']);
        const done = assert.async();

        const response = await fetch(inputRequest1);
        const parsedData = await response.text();

        assert.strictEqual(parsedData.length, 10, 'Response length is correct');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - returns random string with specific range', async (assert) => {
        // blocked_request.json doesn't exist,
        // it's required for test for blocked requests
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;

        runScriptlet(name, ['blocked_request', 'length:50-100']);
        const done = assert.async();

        const response = await fetch(BLOCKED_REQUEST);
        const parsedData = await response.text();
        const headerLength = Number(response.headers.get('Content-Length'));

        assert.ok(parsedData.length >= 50 && parsedData.length <= 100, 'Response length is correct');
        assert.strictEqual(headerLength, parsedData.length, 'Header length matches response length');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - returns random string with single length', async (assert) => {
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;

        runScriptlet(name, ['blocked_request', 'length:75']);
        const done = assert.async();

        const response = await fetch(BLOCKED_REQUEST);
        const parsedData = await response.text();
        const headerLength = Number(response.headers.get('Content-Length'));

        assert.strictEqual(parsedData.length, 75, 'Response length is exactly 75');
        assert.strictEqual(headerLength, parsedData.length, 'Header length matches response length');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - valid response type', async (assert) => {
        const OPAQUE_RESPONSE_TYPE = 'opaque';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        runScriptlet(name, ['*', '', OPAQUE_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);

        assert.strictEqual(response.type, OPAQUE_RESPONSE_TYPE, 'Response type is set');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - valid response type', async (assert) => {
        const OPAQUE_RESPONSE_TYPE = 'opaque';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        runScriptlet(name, ['*', '', OPAQUE_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);

        assert.strictEqual(response.type, OPAQUE_RESPONSE_TYPE, 'Response type is set');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - error response type', async (assert) => {
        const ERROR_RESPONSE_TYPE = 'error';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        runScriptlet(name, ['*', '', ERROR_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);

        assert.strictEqual(response.type, ERROR_RESPONSE_TYPE, 'Response type is set');
        assert.strictEqual(response.status, 0, 'Response status follows filtered type default');
        assert.strictEqual(response.ok, false, 'Response ok follows filtered type default');
        assert.strictEqual(response.body, null, 'Response body is null for filtered type');
        assert.strictEqual(response.url, '', 'Response url is empty for filtered type');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - opaque response type', async (assert) => {
        const OPAQUE_RESPONSE_TYPE = 'opaque';
        // blocked_request.json doesn't exist,
        // it's required for test for blocked requests
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;

        runScriptlet(name, ['blocked_request', '', OPAQUE_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(BLOCKED_REQUEST);

        assert.strictEqual(response.type, OPAQUE_RESPONSE_TYPE, 'Response type is set');
        assert.strictEqual(response.status, 0, 'Response status is set to 0');
        assert.strictEqual(response.statusText, '', 'Response statusText is set to empty string');
        assert.strictEqual(response.body, null, 'Response body is set to null');
        assert.strictEqual(response.headers.get('Content-Length'), null, 'Response hides content-length header');
        assert.strictEqual(response.ok, false, 'Response ok is set to false');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - invalid response type', async (assert) => {
        const INVALID_RESPONSE_TYPE = 'invalid_type';
        const BASIC_RESPONSE_TYPE = 'basic';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        runScriptlet(name, ['*', '', INVALID_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson, 'Request is not modified');

        assert.strictEqual(response.type, BASIC_RESPONSE_TYPE, 'Response type is not modified');
        assert.strictEqual(window.hit, undefined, 'hit function fired');
        done();
    });

    test('simple fetch - invalid response config', async (assert) => {
        const INVALID_RESPONSE_CONFIG = '{"status": "invalid"}';
        const BASIC_RESPONSE_TYPE = 'basic';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        runScriptlet(name, ['*', '', INVALID_RESPONSE_CONFIG]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson, 'Request is not modified');
        assert.strictEqual(response.type, BASIC_RESPONSE_TYPE, 'Response type is not modified');
        assert.strictEqual(window.hit, undefined, 'hit function fired');
        done();
    });

    test('simple fetch - invalid response config statusText value', async (assert) => {
        const INVALID_RESPONSE_VALUE = '{"statusText": "Created"}';
        const BASIC_RESPONSE_TYPE = 'basic';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        runScriptlet(name, ['*', '', INVALID_RESPONSE_VALUE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson, 'Request is not modified');
        assert.strictEqual(response.type, BASIC_RESPONSE_TYPE, 'Response type is not modified');
        assert.strictEqual(window.hit, undefined, 'hit function fired');
        done();
    });

    test('simple fetch - unquoted response config keys are invalid', async (assert) => {
        const INVALID_RESPONSE_VALUE = '{status: 404}';
        const BASIC_RESPONSE_TYPE = 'basic';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/test01.json`;
        const init = {
            method: 'GET',
        };

        const expectedJson = {
            a1: 1,
            b2: 'test',
            c3: 3,
        };

        runScriptlet(name, ['*', '', INVALID_RESPONSE_VALUE]);
        const done = assert.async();

        const response = await fetch(INPUT_JSON_PATH, init);
        const actualJson = await response.json();

        assert.deepEqual(actualJson, expectedJson, 'Request is not modified');
        assert.strictEqual(response.type, BASIC_RESPONSE_TYPE, 'Response type is not modified');
        assert.strictEqual(window.hit, undefined, 'hit function fired');
        done();
    });

    test('simple fetch - response config overrides modified response properties', async (assert) => {
        const TEST_FILE_NAME = 'test01.json';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/${TEST_FILE_NAME}`;
        const inputRequest = new Request(INPUT_JSON_PATH);
        const RESPONSE_VALUE = '{"status": 404, "statusText": "Not Found", "ok": false, '
            + '"redirected": true, "type": "opaqueredirect"}';
        const done = assert.async();

        runScriptlet(name, ['*', 'emptyArr', RESPONSE_VALUE]);

        const response = await fetch(inputRequest);

        assert.strictEqual(response.type, 'opaqueredirect', 'response type is overridden');
        assert.strictEqual(response.status, 404, 'response status is overridden');
        assert.strictEqual(response.statusText, 'Not Found', 'response statusText is overridden');
        assert.strictEqual(response.ok, false, 'response ok is overridden');
        assert.strictEqual(response.redirected, true, 'response redirected is overridden');
        assert.strictEqual(response.url, '', 'response url follows filtered type default');
        assert.strictEqual(response.body, null, 'response body is null for filtered type');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - response config overrides synthetic response properties', async (assert) => {
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;
        const RESPONSE_VALUE = '{"status": 100, "statusText": "Continue", "ok": true, '
            + '"redirected": true, "type": "error"}';
        const done = assert.async();

        runScriptlet(name, ['blocked_request', 'emptyStr', RESPONSE_VALUE]);

        const response = await fetch(BLOCKED_REQUEST);
        const parsedData = await response.text();

        assert.strictEqual(response.type, 'error', 'response type is overridden');
        assert.strictEqual(response.status, 100, 'response status is overridden');
        assert.strictEqual(response.statusText, 'Continue', 'response statusText is overridden');
        assert.strictEqual(response.ok, true, 'response ok is overridden');
        assert.strictEqual(response.redirected, true, 'response redirected is overridden');
        assert.strictEqual(response.url, '', 'response url follows filtered type default');
        assert.strictEqual(parsedData, '', 'response body is preserved as empty string');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch -- all original response properties are not modified', async (assert) => {
        const TEST_FILE_NAME = 'test01.json';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/${TEST_FILE_NAME}`;
        const inputRequest1 = new Request(INPUT_JSON_PATH);
        const done = assert.async();

        runScriptlet(name, ['*']);

        const response = await fetch(inputRequest1);

        /**
         * Previously, only one header was present in the returned response
         * which was `content-type: text/plain;charset=UTF-8`.
         * Since we are not modifying the headers, we expect to receive more than one header.
         * We cannot check the exact headers and their values
         * because the response may contain different headers
         * depending on whether the tests are run in Node or in a browser.
         */
        let headersCount = 0;
        // eslint-disable-next-line no-unused-vars
        for (const key of response.headers.keys()) {
            headersCount += 1;
        }

        assert.strictEqual(response.type, 'basic', 'response type is "basic" by default, not modified');
        assert.true(response.url.includes(TEST_FILE_NAME), 'response url not modified');
        assert.true(headersCount > 1, 'original headers not modified');

        const responseJsonData = await response.json();
        assert.ok(isEmptyObject(responseJsonData), 'response data is mocked');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch -- original response properties are not modified except type', async (assert) => {
        const TEST_FILE_NAME = 'test01.json';
        const TEST_RESPONSE_TYPE = 'opaque';
        const INPUT_JSON_PATH = `${FETCH_OBJECTS_PATH}/${TEST_FILE_NAME}`;
        const inputRequest1 = new Request(INPUT_JSON_PATH);
        const done = assert.async();

        runScriptlet(name, ['*', 'emptyArr', TEST_RESPONSE_TYPE]);

        const response = await fetch(inputRequest1);

        let headersCount = 0;
        // eslint-disable-next-line no-unused-vars
        for (const key of response.headers.keys()) {
            headersCount += 1;
        }

        assert.strictEqual(
            response.type,
            TEST_RESPONSE_TYPE,
            `response type is modified, equals to ${TEST_RESPONSE_TYPE}`,
        );
        assert.strictEqual(response.url, '', 'response url follows filtered type default');
        assert.strictEqual(headersCount, 0, 'headers are empty for filtered type');
        assert.strictEqual(response.body, null, 'response body is null for filtered type');
        assert.strictEqual(response.status, 0, 'response status follows filtered type default');
        assert.strictEqual(response.statusText, '', 'response statusText follows filtered type default');
        assert.strictEqual(response.ok, false, 'response ok follows filtered type default');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - cors response type', async (assert) => {
        const CORS_RESPONSE_TYPE = 'cors';
        // blocked_request.json doesn't exist,
        // it's required for test for blocked requests
        const BLOCKED_REQUEST = `${FETCH_OBJECTS_PATH}/blocked_request.json`;

        runScriptlet(name, ['blocked_request', '', CORS_RESPONSE_TYPE]);
        const done = assert.async();

        const response = await fetch(BLOCKED_REQUEST);

        assert.strictEqual(response.type, CORS_RESPONSE_TYPE, 'Response type is set');
        assert.strictEqual(response.url, BLOCKED_REQUEST, `Response URL is ${BLOCKED_REQUEST}`);
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - cors response type, empty string', async (assert) => {
        const EXPECTED_RESPONSE_TYPE = 'cors';
        const EXPECTED_RESPONSE_REDIRECTED = false;
        const EXPECTED_RESPONSE_STATUS = 200;
        const URL_PATH = '//127.0.0.1/pagead/js/adsbygoogle.js';
        const inputRequest = new Request(URL_PATH);

        runScriptlet(name, ['adsbygoogle', 'emptyStr']);
        const done = assert.async();

        const response = await fetch(inputRequest);
        const parsedData = await response.text();

        assert.strictEqual(response.type, EXPECTED_RESPONSE_TYPE, `Response type is ${EXPECTED_RESPONSE_TYPE}`);
        assert.ok(response.url.endsWith(URL_PATH), `Response URL is ${URL_PATH}`);
        assert.notOk(response.body === null, 'Response body is NOT null');
        assert.strictEqual(
            response.redirected,
            EXPECTED_RESPONSE_REDIRECTED,
            `Response redirected is ${EXPECTED_RESPONSE_REDIRECTED}`,
        );
        assert.strictEqual(response.status, EXPECTED_RESPONSE_STATUS, `Response status is ${EXPECTED_RESPONSE_STATUS}`);
        assert.strictEqual(parsedData, '', 'Response is empty string');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('simple fetch - opaque response type, empty string', async (assert) => {
        const EXPECTED_RESPONSE_TYPE = 'opaque';
        const EXPECTED_RESPONSE_REDIRECTED = false;
        const EXPECTED_RESPONSE_STATUS = 0;
        const URL_PATH = '//127.0.0.1/pagead/js/adsbygoogle.js';
        const options = {
            method: 'HEAD',
            mode: 'no-cors',
        };
        const inputRequest = new Request(URL_PATH, options);

        runScriptlet(name, ['adsbygoogle', 'emptyStr']);
        const done = assert.async();

        const response = await fetch(inputRequest);
        const parsedData = await response.text();

        assert.strictEqual(response.type, EXPECTED_RESPONSE_TYPE, `Response type is ${EXPECTED_RESPONSE_TYPE}`);
        assert.strictEqual(response.url, '', 'Response URL is empty string');
        assert.strictEqual(response.body, null, 'Response body is set to null');
        assert.strictEqual(
            response.redirected,
            EXPECTED_RESPONSE_REDIRECTED,
            `Response redirected is ${EXPECTED_RESPONSE_REDIRECTED}`,
        );
        assert.strictEqual(response.status, EXPECTED_RESPONSE_STATUS, `Response status is ${EXPECTED_RESPONSE_STATUS}`);
        assert.strictEqual(response.statusText, '', 'Response statusText is set to empty string');
        assert.strictEqual(parsedData, '', 'Response is empty string');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });

    test('extension-redirected response should preserve content-length and original URL', async (assert) => {
        const REQUESTED_URL = `${FETCH_OBJECTS_PATH}/pagead/js/adsbygoogle.js`;
        const EXTENSION_URL = 'chrome-extension://foo/pagead/js/adsbygoogle.js';
        const RESPONSE_BODY = 'Response body test';

        // Mock native fetch to simulate browser extension redirect
        window.fetch = () => {
            const resp = new Response(RESPONSE_BODY, {
                status: 200,
                statusText: 'OK',
                headers: {
                    // Extension response is missing Content-Length header
                },
            });
            // Simulate extension-provided URL
            Object.defineProperty(resp, 'url', { value: EXTENSION_URL });
            return Promise.resolve(resp);
        };

        runScriptlet(name, ['adsbygoogle']);
        const done = assert.async();

        const response = await fetch(REQUESTED_URL);

        const contentLengthHeader = response.headers.get('Content-Length');

        assert.ok(contentLengthHeader !== null, 'Content-Length header is present');
        assert.strictEqual(response.url, REQUESTED_URL, 'Response URL is the original requested URL');
        assert.strictEqual(window.hit, 'FIRED', 'hit function fired');
        done();
    });
}
